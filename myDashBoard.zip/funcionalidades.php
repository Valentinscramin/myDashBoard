<?php
include_once "header.php";
?>

	<div class="container">
		<div class="d-flex flex-row justify-content-center'">
			<div>
				<p>A meta deste projeto disponivel no gitHub é apenas mostrar um breve uso do framework.</p>
				<p>O Uso realmente aplicado não será exposto aqui.</p>
				<p>Pelo fato do repositorio ser aberto apenas para fins de demostrar o conhecimento em algumas oportunidades de emprego</p>
				<p>Não irei demostrar tudo, pois por se tratar de condições de Back-End, qualquer privacidade é mera segurança.</p>
				<p>Apenas peço que olhem a forma de desenvolvimento. Obrigado pela atenção.</p>
				<p>Esta versão não esta completa, e está desatualizada.</p>
				<p>E-Mail: Valentin Oliveira Scramin</p>
				<p>Telefone: 19 992371579</p>
			</div>
		</div>
	</div>

<?php
include_once "footer.php";
?>


